# Firefox Hockey Schedule &amp; Score Extension

---
## Current Status - 0.0.1

- Daily NHL schedule
- Auto timezone


---
## Installation

**Install {3d79db25-5fc9-4386-aaf7-0aaf5e07930f}.xpi via Manage extensions/Debug Add-ons/Load Temporary Add-on... only.**
  

---
## Roadmap

- Team selector
- Live scores
- Future schedules
- Game beginning notifications


---
## NHL API -
  
_https://github.com/erunion/sport-api-specifications/tree/master/nhl_  
_https://gitlab.com/dword4/nhlapi/-/tree/master?ref_type=heads_  
_https://gitlab.com/dword4/nhlapi/-/blob/master/swagger/openapi.yaml?ref_type=heads_  
  
---
## ACKNOWLEDGEMENTS - 
*Note; I don't know what I'm doing.*  
  
*Extension initially uses JS from/inspired by [christhoma](https://addons.mozilla.org/en-US/firefox/addon/penguins-2022-2023-schedule/?utm_source=addons.mozilla.org&utm_medium=referral&utm_content=search)
